# Huffman - compression

## Install
simply invoke make

## Usage
* compressing a file:   ./huffman [-c | --compress ] textfile outputfile
* decompressing a file: ./huffman [-d | --decompress ] compressedfile
